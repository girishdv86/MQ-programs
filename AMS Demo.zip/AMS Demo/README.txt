AMS 7.5 Demo
============

This demo will configure a local queue that only alice can put to and bob can get the encrypted messages from, all other users (if they have AMS enabled) will receive security errors, or if a user connects with a client that doesn't have AMS enabled (for example a 7.1 client that doesn't have AMS 7.0.1 enabled) they will get the messages but not be able to decrypt them.

Pre-requisites
--------------
MQ 7.5 installed (with the AMS component selected for installation)
These scripts are windows .cmd scripts, but the contents (with modifications to paths) can be used on Unix
A user called alice (initially with no access to MQ)
A user called bob (initially with no access to MQ)
An administrative user (With full administrative access to MQ)
Each users environment is configured with 7.5 as the installation (<MQ75INSTDIR>\bin\setmqenv -s)


Step 1 - AMS Demo - Step 1.cmd (run as AdminUser)
------
Create and start a queue manager called QM_AMS_VERIFY
Create a local queue to use for testing (TEST.Q)

crtmqm QM_VERIFY_AMS
strmqm QM_VERIFY_AMS
runmqsc QM_VERIFY_AMS
define qlocal(TEST.Q)
end
------

As alice run amqsput TEST.Q QM_VERIFY_AMS (should fail with 2035)
As bob run amqsget TEST.Q QM_VERIFY_AMS (should fail with 2035)

Step 2 - AMS Demo - Step 2.cmd (run as AdminUser)
------
Grant the relevant accesses for alice and bob to QM_VERIFY_AMS etc
setmqaut -m QM_VERIFY_AMS -t qmgr -p alice -p bob +connect +inq

setmqaut -m QM_VERIFY_AMS -n TEST.Q -t queue -p alice +put

setmqaut -m QM_VERIFY_AMS -n TEST.Q -t queue -p bob +get

setmqaut -m QM_VERIFY_AMS -t queue -n SYSTEM.PROTECTION.POLICY.QUEUE -p alice -p bob +browse

setmqaut -m QM_VERIFY_AMS -t queue -n SYSTEM.PROTECTION.ERROR.QUEUE -p alice -p bob +put

------

As alice run amqsput TEST.Q QM_VERIFY_AMS (should be able to now put messages)
As bob run amqsget TEST.Q QM_VERIFY_AMS (should be able to get the messages)

Step 3 - AMS Demo - Step 3.cmd (run as AdminUser)
------
Create a key database for alice
Create a key database for bob
Create a certificate for alice (Alice_Cert) in her key database
Create a certificate for bob (Bob_Cert) in his key database
List the contents of both alice and bob's key databases (should each only contain their own certificate)

NOTE: ENSURE THAT THE PERMISSIONS ON THE KEY DATABASE FILE (.KDB) AND THE PASSWORD STASH FILE (.STH) HAVE APPROPRIATE PERMISSIONS FOR ALICE AND BOB TO BE ABLE TO READ THIER OWN FILES

runmqakm -keydb -create -db "C:/Temp/AMS Test/alice/alicekey.kdb" -pw alice -stash
runmqakm -keydb -create -db "C:/Temp/AMS Test/bob/bobkey.kdb" -pw br3akf4st -stash

runmqakm -cert -create -db "C:/Temp/AMS Test/alice/alicekey.kdb" -pw alice -label Alice_Cert -dn "CN=alice,O=IBM,C=GB"
runmqakm -cert -create -db "C:/Temp/AMS Test/bob/bobkey.kdb" -pw br3akf4st -label Bob_Cert -dn "CN=bob,O=IBM,C=GB" 

runmqakm -cert -list -db "C:/Temp/AMS Test/alice/alicekey.kdb" -pw alice
runmqakm -cert -list -db "C:/Temp/AMS Test/bob/bobkey.kdb" -pw br3akf4st

------

Step 4 - AMS Demo - Step 4.cmd (run as AdminUser)
------
Check the contents of the keystore.conf files for both alice and bob
------

Step 5 - AMS Demo - Step 5.cmd (run as AdminUser)
------
Exhange the public keys of alice and bob, with their counterpart.
Copy alice's public key into bob's key database, and bob's public key into alice's key database
List the contents of each key database (should now show two certificates)

runmqakm -cert -export -db "C:/Temp/AMS Test/alice/alicekey.kdb" -pw alice -label Alice_Cert -target "C:/Temp/AMS Test/bob/bobkey.kdb" -target_pw br3akf4st
runmqakm -cert -export -db "C:/Temp/AMS Test/bob/bobkey.kdb" -pw br3akf4st -label Bob_Cert -target "C:/Temp/AMS Test/alice/alicekey.kdb" -target_pw alice
runmqakm -cert -list -db "C:/Temp/AMS Test/alice/alicekey.kdb" -pw alice
runmqakm -cert -details -db "C:/Temp/AMS Test/bob/bobkey.kdb" -pw br3akf4st -label Alice_Cert
runmqakm -cert -list -db "C:/Temp/AMS Test/bob/bobkey.kdb" -pw br3akf4st
runmqakm -cert -details -db "C:/Temp/AMS Test/alice/alicekey.kdb" -pw alice -label Bob_Cert
------

Step 6 - AMS Demo - Step 6.cmd (run as AdminUser)
------
Create the policy that will define that only alice can put and bob can get from the queue TEST.Q
Display the policy after creation

setmqspl -m QM_VERIFY_AMS -p TEST.Q -s SHA1 -a "CN=alice,O=IBM,C=GB" -e AES256 -r "CN=bob,O=IBM,C=GB"
dspmqspl -m QM_VERIFY_AMS
------

As alice run amqsput TEST.Q QM_VERIFY_AMS (should fail with 2035)
As bob run amqsget TEST.Q QM_VERIFY_AMS (should fail with 2035)

THESE TWO COMMANDS NOW FAIL AGAIN BECAUSE OF AMS.  WE NEED TO POINT EACH USER AT THE CORRECT keystore.conf FILE

As alice run set MQS_KEYSTORE_CONF=<PATHTODEMO>/alice_keystore.conf
As bob run set MQS_KEYSTORE_CONF=<PATHTODEMO>/bob_keystore.conf

As alice run amqsput TEST.Q QM_VERIFY_AMS (should now work again, and the message will be signed and encrypted)
As bob run amqsget TEST.Q QM_VERIFY_AMS (shoudl now work again)

Step 7 - AMS Demo - Step 7.cmd (run as AdminUser)
------
This step will go some way to verifying that the contents of the message on the queue are actually encrypted (i.e. that Step 6 wasn't a lie!)

Create an alias queue TEST.ALIAS, with TEST.Q as the target queue.
Grant Bob access to browse TEST.ALIAS
runmqsc QM_VERIFY_AMS
define qalias(TEST.ALIAS) target(TEST.Q)
end
setmqaut -m QM_VERIFY_AMS -n TEST.ALIAS -t queue -p bob +browse
------

As alice put another message to TEST.Q
AS bob run amqsbcg TEST.ALIAS QM_VERIFY_AMS (this will browse the contents of TEST.Q without decrypting them, since the policy applies only to TEST.Q and not TEST.ALIAS - you should see the message contents encrypted, and other things like the Format field cleared etc).  Browsing the target queue, TEST.Q will return the decrypted contents as the policy will have been applied in that case.

